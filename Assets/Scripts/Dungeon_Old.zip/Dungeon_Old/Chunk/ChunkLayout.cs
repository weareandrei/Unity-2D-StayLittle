using Array2DEditor;
using UnityEngine;

namespace Dungeon_Old.Chunk {
    
    public class ChunkLayout : MonoBehaviour {
        // 0 - empty, 1 - room, 2 - entrance
        [SerializeField] public Array2DInt rooms;
        [SerializeField] public ChunkType quadrantType; 
    }
    
    public enum ChunkType {
        Entrance
    }
    
}