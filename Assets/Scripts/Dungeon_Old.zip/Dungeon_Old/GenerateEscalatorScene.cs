using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateEscalatorScene : MonoBehaviour
{

    [SerializeField] private float maxDistanceElevatorTravel = 500f;
    private void Start() {
        // select randomly
        int randomInt = Random.Range(0, Dungeon_OldsData.countDungeon_Olds()-1);
        Dungeon_OldsData._dungeonData dungeon = Dungeon_OldsData.getDungeon_OldDataByIndex(randomInt);
        Debug.Log("Chosen : " + dungeon.id);
        int stopPositionY = dungeon.depthLevel;

        List<Dungeon_OldsData._dungeonData> dungeonsNearTargetDungeon_Old = new List<Dungeon_OldsData._dungeonData>();

        if (randomInt < Dungeon_OldsData.countDungeon_Olds()-1) {
            dungeonsNearTargetDungeon_Old.Add(Dungeon_OldsData.getDungeon_OldDataByIndex(randomInt+1));
        }

        for (int i = randomInt; i >= 0; i--) {
            if (dungeonsNearTargetDungeon_Old.Count < 5) {
                if ((dungeon.depthLevel - Dungeon_OldsData.getDungeon_OldDataByIndex(randomInt+1).depthLevel) < maxDistanceElevatorTravel) {
                    dungeonsNearTargetDungeon_Old.Add(Dungeon_OldsData.getDungeon_OldDataByIndex(i));
                }
            }
        }

        printList(dungeonsNearTargetDungeon_Old);

        // Now we have a list of dungeons from the target.

        // Now we have them as Scenes (should have generated scenes in GenerateDungeon_Olds for each Dungeon_Old)
        //  so we additively load each scene to make it visible on it's own position.
        //  Or no? Maybe they all already have their positions. and I just need to load and thats it.
        // THEN start the elevator movement until the point.
    }

    private void printList(List<Dungeon_OldsData._dungeonData> dungeonList) {
        foreach(Dungeon_OldsData._dungeonData dungeonData in dungeonList) {
            Debug.Log(dungeonData.id);
        }
    }
}
