using System;
using Unity.VisualScripting;
using UnityEngine;

using Dungeon_Old;

public class GenerateTest : MonoBehaviour
{
    public void Start()
    {
        // Generator.GenerateBySeed("someseed");
    }
}
