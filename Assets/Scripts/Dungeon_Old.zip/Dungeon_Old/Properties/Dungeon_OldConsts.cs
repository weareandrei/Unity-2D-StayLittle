
namespace Dungeon_Old.Properties {

    public static class Dungeon_OldConsts {
        public const int defaultChunkSize = 5;
        public const int maxChunksInDungeon_Old = 6;
    }
    
}