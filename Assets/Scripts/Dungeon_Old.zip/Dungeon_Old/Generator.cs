using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System.Numerics;
using Dungeon_Old.Room;
using Dungeon_Old.Properties;
using Dungeon_Old.Properties.MapUtilities;
using Dungeon_Old.Quadrant;
using Vector2 = UnityEngine.Vector2;

namespace Dungeon_Old {
    
    public static class Generator {
        private static List<RoomInstance> _roomsInstances = GetRoomInstances();
        private static List<ChunkLayout> _chunkLayouts = GetChunkLayouts();
        // Once we have the roomsInstances -> we can make the Dungeon_Old Map
        //  using the ID's filling them into the 2D array.


        public static void GenerateBySeed(string seed) {
            List<ChunkLayout> chunksInUse = new List<ChunkLayout>();
            List<Dungeon_OldMap.ExitData> exitsPending = new List<Dungeon_OldMap.ExitData>();
            // Dungeon_Old consists of Chunks (5x5 rooms)
            // Chunk consists of RoomInstances

            // 2D Dungeon_Old Map (inside Dungeon_OldData) will expand while Dungeon_Old generates
            Dungeon_OldData dungeonData = new Dungeon_OldData();
            dungeonData.roomsAvailable = _roomsInstances; 
            // Dungeon_OldData must know the list of RoomInstance's to be able to apply them

            // In our Dungeon_Old everything is based on Chunks.
            // So we must have a List of Chunk layouts.
            // We load the list and pick a random (appropriate) layout until we reach the  maxChunksInDungeon_Old
            ChunkLayout entranceLayout = ChooseEntranceLayout();

            while (chunksInUse.Count < Dungeon_OldConsts.maxChunksInDungeon_Old
                   && exitsPending.Count > 0) { 
                // Find new Layouts appropriate to existing one's
                Dungeon_OldMap.ExitData thisExit = exitsPending[0];

                Vector2 currentChunkPos = FindChunkPosition(dungeonData, thisExit);
                int[,] exitsLocated = dungeonData.GetNewChunkExitRequirements(currentChunkPos);
                // Now once we have exit pattern - we can find an appropriate Chunk.

                ChunkLayout newChunkLayout = ChooseChunkByExitPattern(exitsLocated);
                dungeonData = ConstructChunk(dungeonData, currentChunkPos, newChunkLayout);

                // We should take those exits because we will then easily
                //  miss other exits attached to new Chunk.
                // Instead we should go around the new Chunk and locate the exits there.

            }
        }

        private static Vector2 FindChunkPosition(Dungeon_OldData dungeonData, Dungeon_OldMap.ExitData mainExit) {
            Vector2 currentChunkPos = default;
            switch (mainExit.exitDirection) {
                case Dungeon_OldMap.ExitDirection.Top:
                    currentChunkPos = dungeonData.FindCurrentChunkUsingCoordinate(mainExit.x, mainExit.y+1);
                    break;
                case Dungeon_OldMap.ExitDirection.Bottom:
                    currentChunkPos = dungeonData.FindCurrentChunkUsingCoordinate(mainExit.x, mainExit.y-1);
                    break;
                case Dungeon_OldMap.ExitDirection.Left:
                    currentChunkPos = dungeonData.FindCurrentChunkUsingCoordinate(mainExit.x-1, mainExit.y);
                    break;
                case Dungeon_OldMap.ExitDirection.Right:
                    currentChunkPos = dungeonData.FindCurrentChunkUsingCoordinate(mainExit.x+1, mainExit.y);
                    break;
                default:
                    Debug.Log("Current mainExit does not have an appropriate exitDirection specified");
                    break;
            }
            return currentChunkPos;
        }

        private static ChunkLayout ChooseEntranceLayout() {
            // Should consider Seed
            foreach (ChunkLayout layout in _chunkLayouts) {
                if (layout.chunkType == ChunkType.Entrance) {
                    return layout;
                }
            }

            return _chunkLayouts[0];
        }

        private static ChunkLayout ChooseChunkByExitPattern(int[,] exitsPattern) {
            foreach (ChunkLayout layout in _chunkLayouts) {

                bool allExitsCorrespond = true;
                for (int y = 0; y < Dungeon_OldConsts.defaultChunkSize; y++) {
                    for (int x = 0; x < Dungeon_OldConsts.defaultChunkSize; x++) {
                        if (layout.rooms.GetCell(x, y) != 2 ||
                            exitsPattern[x, y] != 1) {
                            allExitsCorrespond = false;
                        }
                    }
                }

                if (allExitsCorrespond) {
                    // Should actually be done by SEED. For example if SEED CHAR is 2,
                    //  then second time we enter here - we return.
                    return layout;
                }
            }

            return _chunkLayouts[0];
        }

        private static Dungeon_OldData ConstructChunk(Dungeon_OldData dungeon, Vector2 currentChunkPos, ChunkLayout newChunkLayout) {
            Dungeon_OldData extendedDungeon_Old = dungeon;
            // Go though the Chunk Grid by one room from bottom left to to right.
            //  1 row at a time.
            int chunkStartX = (int)currentChunkPos.x * Dungeon_OldConsts.defaultChunkSize - 1;
            int chunkStartY = (int)currentChunkPos.y * Dungeon_OldConsts.defaultChunkSize - 1;
            for (int y = 0; y < Dungeon_OldConsts.defaultChunkSize-1; y++) {
                for (int x = 0; x < Dungeon_OldConsts.defaultChunkSize-1; x++) {
                    if (newChunkLayout.rooms.GetCell(x, y) != 2) {
                        // Get random exit room here
                        Vector2 roomCoordinates = new Vector2(x,y);
                        extendedDungeon_Old = ChooseExitRoom(extendedDungeon_Old, roomCoordinates);
                    }
                    else {
                        // Get random room here
                    }
                    // They should both correspond to the entire newChunkConstruction schema
                    // : check neighbour cells in newChunkLayout to determine what
                    //    walls are required to be in the room
                }
            }

            return extendedDungeon_Old;
        }

        private static Dungeon_OldData ChooseExitRoom(Dungeon_OldData dungeon, Vector2 roomCoordinates) {
            
        }

        private static List<RoomInstance> GetRoomInstances() {
            const string instancesPath = "Dungeon_Old/Room/Prefabs";
            GameObject[] instancesPrefabs = Resources.LoadAll<GameObject>(instancesPath);
            RoomInstance[] instancesRooms = instancesPrefabs.Select(
                prefabObj => prefabObj.GetComponent<RoomInstance>()
            ).ToArray();
            return new List<RoomInstance>(instancesRooms);
        }
        
        private static List<ChunkLayout> GetChunkLayouts() {
            const string layoutsPath = "Dungeon_Old/Chunk/Prefabs";
            GameObject[] layoutsPrefabs = Resources.LoadAll<GameObject>(layoutsPath);
            ChunkLayout[] chunkLayouts = layoutsPrefabs.Select(
                prefabObj => prefabObj.GetComponent<ChunkLayout>()
            ).ToArray();
            return new List<ChunkLayout>(chunkLayouts);
        }
    }
}